import java.util.*;
public class FeeService {
    private final Set<String> paid = new HashSet<>();
    public String pay(String regNo, String amountText) {
        if (regNo == null || regNo.trim().isEmpty()) return "Enter registration number.";
        double amount;
        try { amount = Double.parseDouble(amountText); }
        catch (Exception ex) { return "Enter a valid amount."; }
        if (amount <= 0) return "Amount must be greater than zero.";
        paid.add(regNo.trim());
        return String.format("Payment recorded: Rs. %.2f", amount);
    }
    public String receipt(String regNo) {
        return paid.contains(regNo.trim()) ? "Receipt available for " + regNo : "No payment found.";
    }
}
