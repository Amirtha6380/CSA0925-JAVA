import java.awt.*;
import java.awt.event.*;
public class FeeWindow extends Frame {
    private final TextField regNo=new TextField(18), amount=new TextField(18);
    private final Label status=new Label("Enter details and select an action.");
    private final FeeService service=new FeeService();
    public FeeWindow() {
        super("Student Fee Payment");
        setLayout(new BorderLayout(8,8));
        Panel fields=new Panel(new GridLayout(2,2,6,6));
        fields.add(new Label("Registration number")); fields.add(regNo);
        fields.add(new Label("Amount (INR)")); fields.add(amount);
        Panel actions=new Panel(new FlowLayout());
        Button pay=new Button("Pay"), clear=new Button("Clear"), receipt=new Button("Receipt");
        pay.addActionListener(e -> status.setText(service.pay(regNo.getText(),amount.getText())));
        clear.addActionListener(e -> {regNo.setText(""); amount.setText(""); status.setText("Fields cleared.");});
        receipt.addActionListener(e -> status.setText(service.receipt(regNo.getText())));
        actions.add(pay); actions.add(clear); actions.add(receipt);
        add(fields,BorderLayout.NORTH); add(actions,BorderLayout.CENTER); add(status,BorderLayout.SOUTH);
        addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){dispose();}});
        setSize(420,180);
    }
    public static void main(String[] a){EventQueue.invokeLater(()->new FeeWindow().setVisible(true));}
}
