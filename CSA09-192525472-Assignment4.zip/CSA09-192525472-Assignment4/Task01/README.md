# Task 1 – GUI Design Review
**Files:** `src/FeeWindow.java`, `src/FeeService.java`

## Diagnosis of the supplied design
1. UI and payment/database logic are mixed, making testing and maintenance difficult.
2. `==` compares String references; use `"Pay".equals(e.getActionCommand())` or dedicated listeners.
3. Empty/non-numeric/negative amounts are not validated and can cause exceptions or incorrect payments.
4. JDBC work and `Thread.sleep()` on the event-dispatch thread freeze repainting and user interaction.
5. There is no clear success/failure feedback; `println` is not visible to the user.
6. Receipt is not implemented as a distinct action.
7. SQL concatenation permits SQL injection; use `PreparedStatement`.
8. Connection and statement resources are not closed safely.
9. Window closing and checked exceptions are not handled.
## Repaired design
`FeeWindow` collects values and displays service results. `FeeService` validates and performs payment logic. In a database-backed version, the service should use a DAO with prepared statements and execute slow work in `SwingWorker`.
## Design defence (under 100 words)
The redesigned window has a narrow responsibility: collect input and present feedback. FeeService contains the business rules and can be tested without opening a window. Changes to the interface therefore do not alter payment validation, while changes to payment rules do not require rewriting event handlers. Dedicated listeners also make each action easier to understand.
## Alternative and complexity
An if/else dispatch chain may perform up to k command comparisons: O(k) worst case and O(1) extra dispatch space. A separate listener/action per button gives direct dispatch, O(1) selection per event, and O(k) listener objects (space). For a small form, either is acceptable; named actions improve reuse as the interface grows.
## Run
`bash run.sh` (requires a graphical desktop and JDK).
