Place genuine execution screenshots and test output for this task in this folder. Do not submit placeholder images as execution evidence.
