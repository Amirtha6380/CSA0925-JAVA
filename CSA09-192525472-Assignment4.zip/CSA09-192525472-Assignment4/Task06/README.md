# Task 6 – Campus Event Registration Desktop Application
## Stage 1 – Requirements
**Users:** student registrant and committee administrator. **Screens:** registration form and committee registration table. **Data:** student ID, event name, registration timestamp. **Rules:** ID is mandatory; one student may register once per event; invalid input is rejected; table data is loaded asynchronously; committee can refresh and export/extend filtering.
## Stage 2 – Screen and event flow
A `JFrame` contains a `JMenuBar` (File → Refresh/Exit), a registration `JPanel` with ID field/event combo/Register button, a central `JTable` in `JScrollPane`, and a status label. Register → validate → database insert → success/error dialog/status → refresh table. Filter/export can be added as additional menu actions.
## Stage 3 – Critical decisions
Validation is in the UI boundary and service layer; duplicate enforcement is guaranteed by a database UNIQUE constraint on `(student_id,event_name)`. JDBC work runs in `SwingWorker`, not on the Event Dispatch Thread. SQL uses `PreparedStatement` and try-with-resources.
## Stage 4 – Layered design
`EventRegistrationApp (UI)` → `RegistrationService (business rules, recommended extraction)` → `RegistrationDAO (JDBC)`. Current compact sample keeps the JDBC calls in worker methods for a runnable demonstration; a production version should extract these two classes. Register pseudocode: trim/validate ID; execute parameterized insert; map unique-constraint violation to duplicate message; refresh table asynchronously. Filter pseudocode: validate filter; execute parameterized SELECT with WHERE; publish rows to JTable on EDT.
## Stage 5 – Implementation
`src/EventRegistrationApp.java` provides Swing UI and asynchronous JDBC operations. `sql/schema.sql` creates the database and unique constraint. Set environment variables `CSA09_DB_URL`, `CSA09_DB_USER`, `CSA09_DB_PASSWORD`; add MySQL Connector/J to the classpath before running.
## Alternative: paging vs loading all
Loading 100,000 rows at once transfers and stores all records, increases startup time and memory O(N), and can make table rendering/EDT updates sluggish. Paging with `LIMIT`/`OFFSET` fetches only page size p, reducing client memory to O(p) and initial transfer to O(p), though deep OFFSET queries can become slower; keyset pagination can improve this. Run database queries in `SwingWorker`.
## Run
Compile with MySQL Connector/J on classpath, e.g. set `MYSQL_JAR=/path/mysql-connector-j.jar` then `bash run.sh`. Configure DB environment variables first.
