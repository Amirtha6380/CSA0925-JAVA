#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${MYSQL_JAR:?Set MYSQL_JAR to the MySQL Connector/J jar path}"
mkdir -p build
javac -cp "$MYSQL_JAR" -d build src/*.java
java -cp "build:$MYSQL_JAR" EventRegistrationApp
