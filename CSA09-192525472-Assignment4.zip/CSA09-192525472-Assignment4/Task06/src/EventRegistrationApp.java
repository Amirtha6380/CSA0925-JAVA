import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
public class EventRegistrationApp extends JFrame {
    private final JTextField student=new JTextField(12);
    private final JComboBox<String> event=new JComboBox<>(new String[]{"Tech Fest","Cultural Night","Sports Meet"});
    private final DefaultTableModel model=new DefaultTableModel(new String[]{"Student ID","Event"},0);
    private final JTable table=new JTable(model);
    private final JLabel status=new JLabel("Ready");
    private final String url=System.getenv().getOrDefault("CSA09_DB_URL","jdbc:mysql://localhost:3306/csa09");
    private final String user=System.getenv().getOrDefault("CSA09_DB_USER","root");
    private final String password=System.getenv().getOrDefault("CSA09_DB_PASSWORD","");
    public EventRegistrationApp(){
        super("Campus Event Registration");
        setLayout(new BorderLayout(8,8));
        JPanel form=new JPanel(new FlowLayout(FlowLayout.LEFT));form.add(new JLabel("Student ID"));form.add(student);form.add(event);
        JButton register=new JButton("Register");form.add(register);
        JMenuBar bar=new JMenuBar();JMenu file=new JMenu("File");JMenuItem refresh=new JMenuItem("Refresh"),exit=new JMenuItem("Exit");file.add(refresh);file.add(exit);bar.add(file);setJMenuBar(bar);
        add(form,BorderLayout.NORTH);add(new JScrollPane(table),BorderLayout.CENTER);add(status,BorderLayout.SOUTH);
        register.addActionListener(e->register());refresh.addActionListener(e->load());exit.addActionListener(e->dispose());
        setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(700,420);setLocationRelativeTo(null);load();
    }
    private Connection connect() throws SQLException{return DriverManager.getConnection(url,user,password);}
    private void register(){
        String id=student.getText().trim(), ev=(String)event.getSelectedItem();
        if(id.isEmpty()){status.setText("Student ID is required.");return;}
        status.setText("Registering...");
        new SwingWorker<String,Void>(){
            protected String doInBackground() throws Exception{
                String sql="INSERT INTO registrations(student_id,event_name) VALUES(?,?)";
                try(Connection c=connect();PreparedStatement p=c.prepareStatement(sql)){
                    p.setString(1,id);p.setString(2,ev);p.executeUpdate();return "Registration successful.";
                }catch(SQLIntegrityConstraintViolationException ex){return "Duplicate registration rejected.";}
            }
            protected void done(){try{status.setText(get());load();}catch(Exception ex){status.setText("Registration failed: "+ex.getCause().getMessage());}}
        }.execute();
    }
    private void load(){
        new SwingWorker<DefaultTableModel,Void>(){
            protected DefaultTableModel doInBackground() throws Exception{
                DefaultTableModel m=new DefaultTableModel(new String[]{"Student ID","Event"},0);
                try(Connection c=connect();PreparedStatement p=c.prepareStatement("SELECT student_id,event_name FROM registrations ORDER BY student_id,event_name");ResultSet r=p.executeQuery()){
                    while(r.next())m.addRow(new Object[]{r.getString(1),r.getString(2)});
                }return m;
            }
            protected void done(){try{DefaultTableModel m=get();model.setRowCount(0);for(int i=0;i<m.getRowCount();i++)model.addRow(new Object[]{m.getValueAt(i,0),m.getValueAt(i,1)});}catch(Exception ex){status.setText("Load failed. Check MySQL/JDBC settings.");}}
        }.execute();
    }
    public static void main(String[] a){SwingUtilities.invokeLater(()->new EventRegistrationApp().setVisible(true));}
}
