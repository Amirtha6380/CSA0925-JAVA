# Task 2 – Hospital Outpatient Appointment Desk

## 2.1 Event model
| Event source | Event object | Listener | Action |
|---|---|---|---|
| Department combo | ItemEvent/ActionEvent | ItemListener/ActionListener | Refresh doctor choices |
| Book button | ActionEvent | ActionListener | Validate and book |
| Window close | WindowEvent | WindowListener/WindowAdapter | Confirm if booking is active |
| Time slot combo | ActionEvent | ActionListener (optional) | Update selected slot |
## 2.2 Component hierarchy
`JFrame AppointmentDesk (BorderLayout)` → `JPanel form (GridLayout 4×2)` → patient `JTextField`, department/doctor/time `JComboBox`; `JPanel bottom (FlowLayout)` → Book `JButton`, status `JLabel`.
## 2.3 Handler pseudocode
**Refresh doctors:** read selected department; clear doctor combo; for each doctor mapped to department, add item; select first item if present.
**Book:** validate non-empty patient ID and selections; mark booking active; run service/database request in SwingWorker; on completion show confirmation or error and clear active flag.
## 2.4 Event trace
main → `invokeLater` → constructor → component/listener registration → `setVisible` → department ActionEvent → `refreshDoctors` → Book ActionEvent → `book` → SwingWorker background operation → `done` → close request → `windowClosing` → confirmation → `dispose`. Unlike an applet's `init/start/paint/stop/destroy` lifecycle, a desktop frame is created by application code and responds to events until disposed.
## Alternative / complexity
Preloading a map costs O(m) time and O(m) memory for m doctor records; a department change then takes O(r) to populate r doctors (or O(1) lookup plus rendering). Fetching on every change adds database/network latency per change and avoids retaining the full map locally (roughly O(r) displayed records). For a small stable directory, caching is faster; refresh/invalidation may be needed for changing data.
## Run
`bash run.sh` (requires JDK and graphical desktop).
