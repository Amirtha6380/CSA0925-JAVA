import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class AppointmentDesk extends JFrame {
    private final JTextField patientId=new JTextField(12);
    private final JComboBox<String> department=new JComboBox<>(new String[]{"Cardiology","Neurology","Orthopaedics"});
    private final JComboBox<String> doctor=new JComboBox<>();
    private final JComboBox<String> slot=new JComboBox<>(new String[]{"09:00","10:00","11:30","14:00"});
    private final JLabel status=new JLabel("Complete the form to book.");
    private boolean bookingInProgress=false;
    private final Map<String,java.util.List<String>> doctors=Map.of(
        "Cardiology",java.util.List.of("Dr. Rao","Dr. Meena"),
        "Neurology",java.util.List.of("Dr. Kumar","Dr. Iyer"),
        "Orthopaedics",java.util.List.of("Dr. Das","Dr. Shah"));
    public AppointmentDesk(){
        super("Hospital Outpatient Appointment Desk");
        setLayout(new BorderLayout(8,8));
        JPanel form=new JPanel(new GridLayout(4,2,8,8));
        form.add(new JLabel("Patient ID"));form.add(patientId);
        form.add(new JLabel("Department"));form.add(department);
        form.add(new JLabel("Doctor"));form.add(doctor);
        form.add(new JLabel("Time slot"));form.add(slot);
        JButton book=new JButton("Book appointment");
        JPanel bottom=new JPanel(new FlowLayout());bottom.add(book);bottom.add(status);
        add(form,BorderLayout.CENTER);add(bottom,BorderLayout.SOUTH);
        department.addActionListener(e->refreshDoctors());
        book.addActionListener(e->book());
        addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){
            if(bookingInProgress && JOptionPane.showConfirmDialog(AppointmentDesk.this,"A booking is in progress. Close?","Confirm",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
            dispose();
        }});
        refreshDoctors();setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);setSize(570,240);setLocationRelativeTo(null);
    }
    private void refreshDoctors(){doctor.removeAllItems();for(String d:doctors.get((String)department.getSelectedItem()))doctor.addItem(d);}
    private void book(){
        String id=patientId.getText().trim();
        if(id.isEmpty()){status.setText("Patient ID is required.");return;}
        bookingInProgress=true;
        new SwingWorker<String,Void>(){
            protected String doInBackground() throws Exception {Thread.sleep(400);return "Appointment confirmed for "+id+" with "+doctor.getSelectedItem()+" at "+slot.getSelectedItem();}
            protected void done(){try{status.setText(get());}catch(Exception ex){status.setText("Booking failed.");}finally{bookingInProgress=false;}}
        }.execute();
    }
    public static void main(String[] a){SwingUtilities.invokeLater(()->new AppointmentDesk().setVisible(true));}
}
