# Task 3 – Campus Library Search Screen
## Layout decisions
- Root `JFrame`: `BorderLayout`; the central results scroll pane receives remaining space and grows on resize.
- Search controls: `FlowLayout(LEFT)` to keep text field, category and Search button in one compact row.
- Bottom navigation: `FlowLayout`; status is placed below it in a nested `BorderLayout` panel.
- `JScrollPane` around `JList` keeps results usable when the list exceeds the available area.
## Nested structure
`JFrame(BorderLayout)` → north title; search panel (FlowLayout); center JScrollPane/JList; south panel (BorderLayout) → navigation panel (FlowLayout) + status label.
## Resizing test plan
Run the application and capture screenshots at 650×420, 900×600 and 1200×760. Verify that the results region expands while the controls remain their preferred size. Screenshots must be captured from the actual running program on your machine; no fabricated evidence is included.
## Alternative analysis
`GridBagLayout` can express flexible weights and constraints but has more setup. Absolute positioning has low initial setup but does not adapt to resizing, font scaling or platform differences. Nested layout managers create a few extra containers (O(p) for p panels); both layout calculation and component placement are generally O(c) in c components. The nested design is maintainable and responsive.
## Run
`bash run.sh`.
