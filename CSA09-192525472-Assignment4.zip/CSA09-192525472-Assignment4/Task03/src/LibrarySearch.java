import javax.swing.*;
import java.awt.*;
public class LibrarySearch extends JFrame {
    public LibrarySearch(){
        super("Campus Library Search");
        setLayout(new BorderLayout(8,8));
        JLabel title=new JLabel("Campus Library – Search Catalogue",SwingConstants.CENTER);
        JPanel search=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField query=new JTextField(22);JComboBox<String> category=new JComboBox<>(new String[]{"All","Books","Journals","Theses"});
        JButton find=new JButton("Search");search.add(new JLabel("Keyword"));search.add(query);search.add(category);search.add(find);
        DefaultListModel<String> model=new DefaultListModel<>();model.addElement("Java Programming – Available");model.addElement("Event-Driven Systems – Reference");
        JList<String> results=new JList<>(model);
        JScrollPane centre=new JScrollPane(results);
        JPanel nav=new JPanel(new FlowLayout());JButton prev=new JButton("Prev"),next=new JButton("Next"),reserve=new JButton("Reserve");
        nav.add(prev);nav.add(next);nav.add(reserve);
        JLabel status=new JLabel("Ready");
        JPanel south=new JPanel(new BorderLayout());south.add(nav,BorderLayout.CENTER);south.add(status,BorderLayout.SOUTH);
        add(title,BorderLayout.NORTH);add(search,BorderLayout.BEFORE_LINE_BEGINS);add(centre,BorderLayout.CENTER);add(south,BorderLayout.SOUTH);
        find.addActionListener(e->{status.setText("Search requested: "+query.getText()+" / "+category.getSelectedItem());});
        prev.addActionListener(e->status.setText("Previous page"));next.addActionListener(e->status.setText("Next page"));
        reserve.addActionListener(e->status.setText("Selected item: "+results.getSelectedValue()));
        setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(650,420);setLocationRelativeTo(null);
    }
    public static void main(String[] a){SwingUtilities.invokeLater(()->new LibrarySearch().setVisible(true));}
}
