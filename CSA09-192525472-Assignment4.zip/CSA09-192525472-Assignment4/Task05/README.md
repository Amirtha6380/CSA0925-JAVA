# Task 5 – Same Screen, Different Event-Handling Styles
## Four implementations
`ConverterStyles.java` demonstrates: (a) frame implements `ActionListener`; (b) named inner class; (c) anonymous inner class; (d) lambda. `Converter.java` completes the lambda exercise and registers one shared lambda with both Convert and Enter actions. A `WindowAdapter` is not needed in Swing here because `EXIT_ON_CLOSE` is configured; in AWT the equivalent close handling uses `WindowAdapter`.
## Requirement change
The lambda implementation reuses one `ActionListener` instance for the button and text field. The handler parses the amount, formats two decimal places, displays the result label and shows a dialog. Invalid input produces an error label and dialog.
## Comparison
| Style | Readability | Field access | Reuse/change |
|---|---|---|---|
| Frame implements listener | Simple for tiny forms; mixes roles | Direct | Reuse limited; frame becomes coupled |
| Named inner class | Explicit and descriptive | Direct | Good when handler has substantial logic |
| Anonymous class | Local but verbose | Direct | Convenient for one-off handler |
| Lambda | Concise for functional interface | Lexical access | Best for short actions; extract method for complex logic |
For a large application, use separate action/service classes or Swing `Action` objects to share behavior across buttons, menus and shortcuts.
## Alternative
A method reference (`this::convert`) is concise when signatures match. One shared `Action` can be attached to button/menu/keyboard binding and centralizes enabled state and name. It reduces duplicated handler objects and makes adding triggers straightforward.
## Run
`bash run.sh` launches the lambda version; `bash run-styles.sh` launches all four styles.
