import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class ConverterStyles extends JFrame implements ActionListener {
    private final JTextField amount=new JTextField(8); private final JLabel output=new JLabel(" ");
    public ConverterStyles(){
        super("Converter Handler Styles");setLayout(new FlowLayout());
        JButton self=new JButton("Self"), named=new JButton("Inner"), anonymous=new JButton("Anonymous"), lambda=new JButton("Lambda");
        self.addActionListener(this);
        named.addActionListener(new NamedHandler());
        anonymous.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){convert();}});
        lambda.addActionListener(e->convert());
        add(amount);add(self);add(named);add(anonymous);add(lambda);add(output);
        setDefaultCloseOperation(EXIT_ON_CLOSE);pack();
    }
    public void actionPerformed(ActionEvent e){convert();}
    private class NamedHandler implements ActionListener {public void actionPerformed(ActionEvent e){convert();}}
    private void convert(){try{double v=Double.parseDouble(amount.getText());output.setText(String.format("%.2f USD",v*0.012));}catch(Exception ex){output.setText("Invalid amount");}}
    public static void main(String[] a){SwingUtilities.invokeLater(()->new ConverterStyles().setVisible(true));}
}
