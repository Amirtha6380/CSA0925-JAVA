import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
public class Converter extends JFrame {
    private final JTextField amount=new JTextField(10);
    private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"});
    private final JLabel result=new JLabel(" ");
    private static double rate(String c){return c.equals("USD")?0.012:0.011;}
    public Converter(){
        super("Currency Converter – Lambda");setLayout(new FlowLayout());
        JButton convert=new JButton("Convert");add(new JLabel("INR"));add(amount);add(target);add(convert);add(result);
        ActionListener action=e->convert();
        convert.addActionListener(action);amount.addActionListener(action);
        setDefaultCloseOperation(EXIT_ON_CLOSE);pack();setLocationRelativeTo(null);
    }
    private void convert(){
        try{
            double value=Double.parseDouble(amount.getText().trim());
            if(value<0)throw new NumberFormatException();
            String text=new DecimalFormat("0.00").format(value*rate((String)target.getSelectedItem()));
            result.setText(text+" "+target.getSelectedItem());
            JOptionPane.showMessageDialog(this,"Converted amount: "+text+" "+target.getSelectedItem(),"Conversion",JOptionPane.INFORMATION_MESSAGE);
        }catch(NumberFormatException ex){result.setText("Invalid amount");JOptionPane.showMessageDialog(this,"Invalid amount","Input error",JOptionPane.ERROR_MESSAGE);}
    }
    public static void main(String[] a){SwingUtilities.invokeLater(()->new Converter().setVisible(true));}
}
