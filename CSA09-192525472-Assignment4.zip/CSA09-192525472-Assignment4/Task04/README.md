# Task 4 – Event-Handling Forensics
## 4.1 Defect
The method is misspelled `mouseclicked`; Java's listener callback is `mouseClicked` (capital C). It therefore does not override the adapter method and is never invoked. The label is never updated because the callback body does not run.
## 4.2 Failing interaction
Click to draw, minimise the frame, then restore it. A dot drawn directly through `getGraphics()` is not part of the component's retained state and may be erased during repaint/expose.
## 4.3 Repair
The program stores each click as a `Point`, updates the label, calls `repaint()`, and draws all stored points in `paint()`. Each dot is a 6×6 oval centred on its click coordinate.
## 4.4 Prevention
`@Override` asks the compiler to verify that the method overrides a superclass/interface method. With the misspelled method, compilation reports that it does not override or implement a method from a supertype.
## Alternative / complexity
Retained point list: repaint traverses n points, O(n) time; storage O(n). A `BufferedImage` draws each dot once and repaint copies the image, approximately O(width×height) for a full image copy (or optimized dirty-region cost), with O(width×height) pixel storage. For many points and frequent repaints, an image can reduce repeated drawing work.
## Run
`bash run.sh`; click several positions, then minimise/restore to verify persistence.
