# SIMATS Engineering – Programming in Java
## Assignment 4 – CO4: Event-Driven GUI Design
**Register number:** 192525472 (copied from the supplied Assignment 1 sample folder; verify before submission)  
**Course:** CSA09 – Programming in Java  
**Java version:** Java 17 or later recommended

## Repository structure
- `Task01` – Fee payment design review and repaired AWT application
- `Task02` – Hospital appointment desk and event model
- `Task03` – Campus library search layout
- `Task04` – Mouse event debugging and repaint-safe drawing pad
- `Task05` – Four event handling styles and completed lambda converter
- `Task06` – Campus event registration Swing/JDBC application and SQL schema

Each task folder contains `src`, a `README.md`, and a `run.sh` (Task05 also has `run-styles.sh`). Task06 requires MySQL Connector/J and a configured MySQL database.

## Compile and run
Open a terminal in the required task folder and execute the corresponding script. On Linux/macOS/WSL with GUI support: `bash run.sh`. On Windows, compile the `.java` files using `javac` and run the main class from the task folder. A graphical desktop is required for AWT/Swing windows.

## Evidence and verification checklist
- Run each GUI program on the target machine.
- Save genuine screenshots in the matching `TaskXX/output/` folder, with descriptive names (for example `Task03_900x600.png`).
- For Task04 capture before and after minimising/restoring.
- For Task05 capture a valid conversion and invalid amount.
- For Task06 capture normal, invalid and duplicate registration tests after configuring MySQL.
- Commit each task separately to GitHub as required by the assignment brief.
- Replace this README's register number if it is not correct and add your name and GitHub repository URL.

**Important:** Output screenshot folders are intentionally not populated with fabricated screenshots. The assignment requires evidence of your own execution, and GUI screenshots must be captured from a real run.
