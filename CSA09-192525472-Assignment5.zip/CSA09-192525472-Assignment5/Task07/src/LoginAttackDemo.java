import java.sql.*;
public class LoginAttackDemo {
    public static boolean unsafeLogin(Connection c,String id,String pwd)throws SQLException{
        String sql="SELECT 1 FROM users WHERE id='"+id+"' AND pwd='"+pwd+"'";
        try(Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){return r.next();}
    }
    public static boolean safeLogin(Connection c,String id,String pwd)throws SQLException{
        try(PreparedStatement p=c.prepareStatement("SELECT 1 FROM users WHERE id=? AND pwd=?")){
            p.setString(1,id);p.setString(2,pwd);try(ResultSet r=p.executeQuery()){return r.next();}
        }
    }
    public static void main(String[] args){System.out.println("Run against your isolated local assignment database; compare unsafe and prepared login results.");}
}
