# A2 – Don’t Read What You Don’t Need (5 marks)
A 50 MiB file read one byte at a time performs approximately 52,428,800 Java `read()` calls (50 × 1024 × 1024 bytes). Each call adds method and potentially native/OS I/O overhead; actual physical reads may be coalesced by lower-level caches.
Use `BufferedInputStream` with a byte array (e.g. 8–64 KiB) or `BufferedReader` and count newline characters. This changes user-level reads from O(file size) calls to O(file size / buffer size) bulk reads. Buffering helps less for in-memory streams or when the consumer is already receiving large blocks.
**Alternative `Files.readAllLines`:** O(N) time but O(N) memory for all decoded lines (and object overhead); buffered streaming is O(N) time and O(B) working memory for buffer B. Read-all is convenient for small files that fit comfortably in memory; streaming is preferred for 50 MB or unbounded logs.
## Implementation
`src/LineCounter.java` compares a buffered line counter and a byte-at-a-time counter. Run `bash run.sh <path-to-log>`.
## Measurement
Record actual elapsed times in `measurements.csv`; do not use predicted values as measured evidence.
