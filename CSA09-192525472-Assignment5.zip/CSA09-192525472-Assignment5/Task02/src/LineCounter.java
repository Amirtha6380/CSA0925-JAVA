import java.io.*;
import java.nio.file.*;
public class LineCounter {
    public static long countBuffered(Path path) throws IOException {
        long count=0;
        try(BufferedReader reader=Files.newBufferedReader(path)){
            while(reader.readLine()!=null) count++;
        }
        return count;
    }
    public static long countUnbuffered(Path path) throws IOException {
        long count=0; boolean hasData=false;
        try(InputStream in=Files.newInputStream(path)){
            int b; while((b=in.read())!=-1){hasData=true;if(b=='\n')count++;}
        }
        // Count a final non-empty line without a trailing newline.
        if(hasData){
            try(RandomAccessFile f=new RandomAccessFile(path.toFile(),"r")){
                if(f.length()>0){f.seek(f.length()-1);if(f.read()!='\n')count++;}
            }
        }
        return count;
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=1){System.out.println("Usage: java LineCounter <file>");return;}
        Path p=Path.of(args[0]);
        System.out.println("Buffered lines: "+countBuffered(p));
        System.out.println("Unbuffered lines: "+countUnbuffered(p));
    }
}
