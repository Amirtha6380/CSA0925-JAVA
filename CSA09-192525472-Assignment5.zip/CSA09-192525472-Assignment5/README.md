# SIMATS Engineering – Programming in Java
## Assignment 5 – CO5: Data Persistence Engineering – Files and Databases
**Register number:** 192525472 (copied from the Assignment 1 model ZIP; verify before submission)  
**Java:** Java 17 or later recommended  
**Course:** CSA09 – Programming in Java

## Repository map
| Folder | Assignment section | Main contents |
|---|---|---|
| Task01 | A1 File format | Record layouts, pseudocode, recovery design |
| Task02 | A2 Buffered I/O | LineCounter.java, timing template |
| Task03 | A3 DAO pattern | Dao<T,K>, Student, StudentDao, SQL |
| Task04 | A4 Serialization | Hostel/Room/Resident serializable graph |
| Task05 | A5 Transactions & injection | WalletTransfer, LoginCheck |
| Task06 | B1 File store | Completed PassStore TODO, tests |
| Task07 | B2 Adversarial inputs | Unsafe vs prepared login demo and test plan |
| Task08 | B3 JDBC performance | Completed PassLoader TODOs, schema, benchmark template |
| Task09 | B4 Migration | File validation, batch transaction, metadata inspection |

Every task folder includes its own README and source code where implementation is required. SQL schemas, sample input and measurement templates are included.

## Compile and execute
Run `bash run.sh` inside each implementation task folder. Tasks 3, 5 (JDBC), 8 database operations and 9 migration require MySQL Connector/J and a configured local assignment database. Set:
- `CSA09_DB_URL` (e.g. `jdbc:mysql://localhost:3306/csa09_assignment5`)
- `CSA09_DB_USER`
- `CSA09_DB_PASSWORD`
- `MYSQL_JAR` for scripts that need the driver JAR.

Run SQL files before database tasks. Do not commit real passwords.

## Evidence required before submission
- Capture real execution screenshots for every implemented task and store them in that task's `output/` directory.
- Complete measurement CSV files with actual timings from your machine/database. Blank measurement cells are intentional; fabricated benchmark data is not supplied.
- For B2, run only against a disposable local test database.
- Add your name and GitHub repository URL; create `CSA09-192525472-Assignment5` and commit each task progressively as required by the assignment brief.
- Verify register number before publishing.
