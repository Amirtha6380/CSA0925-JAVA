# B1 – Implement and Instrument the File Store (7 marks)
`PassStore` implements add, find and list-by-route with buffered character streams. `find` completes the assignment's TODO: reads line-by-line in try-with-resources, skips records whose field count is not five or whose numeric fields are invalid, and returns the matching fields or null.
Expected complete-code output:
```
[P1003, 192311003, Divya, 7, 3800.0]
null
```
The damaged P1002 line has only two fields, so it is skipped; the loop continues and does not terminate the search.
Test normal add/find, unknown ID, wrong field count, non-numeric amount, empty line, route listing. Record actual 1/10/50 MB buffered/unbuffered times and find-time measurements for 1,000–100,000 records in `measurements.csv`. Do not fabricate timings.
## Run
`bash run.sh` (prints the expected output).
