# A1 – Design a File Format (7 marks)

## A1.1 Record layouts
**Delimited text:** `passId|regNo|name|routeNo|boardingStop|validityDate|amountPaid` (UTF-8, one record per line). Use `|` as delimiter and escape backslash and delimiter in text fields (`\` → `\\`, `|` → `\|`). A parser must understand escapes rather than using a naïve split. Store dates as ISO-8601 (`yyyy-MM-dd`) and amounts as decimal text.
**Binary DataOutputStream:** write fields in the same logical order: `writeUTF(passId)`, `writeUTF(regNo)`, `writeUTF(name)`, `writeInt(routeNo)`, `writeUTF(boardingStop)`, `writeUTF(validityDate)`, `writeDouble(amountPaid)`. `writeUTF` is length-prefixed modified UTF-8, so variable-length strings need not be padded. Include a file header/version and record count for robust parsing.
## A1.2 Operations – SIMATS-style pseudocode
**ADD PASS**
1. OPEN `BufferedWriter` over `FileWriter(file, APPEND)` (or `Files.newBufferedWriter`).
2. VALIDATE required fields and numeric/date formats.
3. ENCODE delimiter characters; WRITE one complete record; WRITE newline.
4. FLUSH and CLOSE using try-with-resources.
5. REPORT success; on IOException report failure and retain the original file.
**FIND BY PASS ID**
1. OPEN `BufferedReader` over `FileReader`.
2. WHILE `READLINE` returns a line: parse escaped fields; if field count is not seven, record/skip damaged line; otherwise compare pass ID; return matching record.
3. CLOSE reader; if no match, return NOT FOUND.
**LIST BY ROUTE**
1. OPEN buffered reader.
2. READ each line; parse and validate; skip malformed records.
3. IF route number matches requested route, DISPLAY record.
4. CLOSE reader.
`BufferedReader`/`BufferedWriter` reduce small I/O calls; `FileReader`/`FileWriter` are character streams suitable for text. Use `FileInputStream`/`FileOutputStream` with `DataInputStream`/`DataOutputStream` for binary records.
## A1.3 Damaged data
Validate field count, date, route and amount; log line number and reason, skip the damaged record and continue. If file is missing, distinguish `NoSuchFileException` and offer a controlled empty-store initialization only when appropriate. For power failure, append may leave a partial final line; write to a temporary file then atomic-move for full rewrites, and use checksums/record terminators or a journal for stronger recovery.
## Alternative: RandomAccessFile
With fixed-size records, record i is reached by `seek(i × recordSize)`, O(1) once the index is known. Finding by ID without an index still scans O(n); maintain an ID-to-offset index for fast lookup. Fixed-width fields waste space when values are shorter than their allocated maximum; variable-width text is compact but scans sequentially.
