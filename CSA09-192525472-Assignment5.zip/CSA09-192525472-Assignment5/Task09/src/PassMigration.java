import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
public class PassMigration {
    public static void main(String[] args)throws Exception{
        if(args.length!=1){System.out.println("Usage: java PassMigration <passes.csv>");return;}
        String url=System.getenv("CSA09_DB_URL"),user=System.getenv("CSA09_DB_USER"),pwd=System.getenv("CSA09_DB_PASSWORD");
        List<String[]> valid=new ArrayList<>();List<String> failures=new ArrayList<>();int lineNo=0;
        try(BufferedReader r=Files.newBufferedReader(Path.of(args[0]))){
            String line;while((line=r.readLine())!=null){lineNo++;String[] f=line.split(",",-1);
                try{if(f.length!=5)throw new IllegalArgumentException("expected 5 fields");
                    if(f[0].isBlank()||f[1].isBlank()||f[2].isBlank())throw new IllegalArgumentException("required field missing");
                    Integer.parseInt(f[3]);double amount=Double.parseDouble(f[4]);if(amount<0)throw new IllegalArgumentException("negative amount");
                    valid.add(f);
                }catch(RuntimeException ex){failures.add("Line "+lineNo+": "+ex.getMessage());}
            }
        }
        try(Connection c=DriverManager.getConnection(url,user,pwd)){
            int inserted=PassLoaderBridge.load(c,valid);
            DatabaseMetaData md=c.getMetaData();
            System.out.println("Database: "+md.getDatabaseProductName());
            System.out.println("Driver: "+md.getDriverName()+" "+md.getDriverVersion());
            try(ResultSet t=md.getTables(null,null,"%",new String[]{"TABLE"})){while(t.next())System.out.println("Table: "+t.getString("TABLE_NAME"));}
            System.out.println("Inserted: "+inserted);
        }
        for(String f:failures)System.out.println("Rejected: "+f);
    }
}
class PassLoaderBridge {
    static int load(Connection c,List<String[]> rows)throws SQLException{
        String q="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
        boolean old=c.getAutoCommit();c.setAutoCommit(false);
        try(PreparedStatement p=c.prepareStatement(q)){
            int n=0;for(String[] r:rows){p.setString(1,r[0]);p.setString(2,r[1]);p.setString(3,r[2]);p.setInt(4,Integer.parseInt(r[3]));p.setDouble(5,Double.parseDouble(r[4]));p.addBatch();n++;if(n%1000==0)p.executeBatch();}
            p.executeBatch();c.commit();return n;
        }catch(Exception e){c.rollback();if(e instanceof SQLException)throw (SQLException)e;throw new SQLException(e);}
        finally{c.setAutoCommit(old);}
    }
}
