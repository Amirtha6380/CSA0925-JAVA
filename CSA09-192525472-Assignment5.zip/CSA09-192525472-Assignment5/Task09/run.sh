#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${MYSQL_JAR:?Set MYSQL_JAR to MySQL Connector/J jar}"
mkdir -p build
javac -cp "$MYSQL_JAR:../Task08/src" -d build src/*.java ../Task08/src/PassLoader.java
java -cp "build:$MYSQL_JAR" PassMigration "$@"
