import java.sql.*;
import java.util.*;
public class BatchBenchmark {
    public static List<String[]> generate(int n){
        List<String[]> rows=new ArrayList<>(n);
        for(int i=1;i<=n;i++)rows.add(new String[]{"P"+i,"1923"+String.format("%05d",i),"Student"+i,String.valueOf((i%20)+1),"4500.00"});
        return rows;
    }
    public static void main(String[] a)throws Exception{
        System.out.println("Configure CSA09_DB_URL, CSA09_DB_USER, CSA09_DB_PASSWORD and MySQL Connector/J.");
        System.out.println("Use PassLoader.loadAll(connection, generate(1000/10000/100000)) after clearing the table between trials.");
    }
}
