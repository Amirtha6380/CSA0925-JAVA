# B3 – Statement vs PreparedStatement vs Batch (8 marks)
`PassLoader.loadAll` completes all three TODOs: binds five values, adds each row to the batch, executes every 1,000 rows and at the end, commits on success, and rolls back on SQL/runtime failure before rethrowing. It restores the prior auto-commit setting.
Create the schema with `sql/schema.sql`. Compare Statement, PreparedStatement and PreparedStatement batching for 10, 1,000, 10,000 and 100,000 rows. Clear table between trials and use identical generated data. Repeat auto-commit and transaction tests, injecting a controlled invalid row midway; auto-commit may retain earlier inserts while a single transaction should leave no partial inserts after rollback.
For n rows, all approaches perform O(n) row work. Batching reduces network round trips; memory is O(b) for batch size b. Multi-row INSERT may reduce round trips but SQL statement size grows; MySQL LOAD DATA is optimized for bulk import and generally best for large files, subject to validation/operational requirements.
## Run
`bash run.sh` compiles the standalone code; database benchmarking requires MySQL Connector/J and configured credentials.
