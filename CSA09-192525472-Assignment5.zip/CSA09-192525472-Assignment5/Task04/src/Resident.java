import java.io.Serializable;
public class Resident implements Serializable {
    private static final long serialVersionUID=1L;
    private String name,registerNumber,phoneNumber;
    private transient String password;
    public Resident(String name,String registerNumber,String password,String phoneNumber){
        this.name=name;this.registerNumber=registerNumber;this.password=password;this.phoneNumber=phoneNumber;
    }
    public String toString(){return name+" ("+registerNumber+"), phone="+phoneNumber;}
}
