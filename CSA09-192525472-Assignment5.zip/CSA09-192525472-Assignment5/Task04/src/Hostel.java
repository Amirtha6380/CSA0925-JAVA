import java.io.*;
import java.util.*;
public class Hostel implements Serializable {
    private static final long serialVersionUID=1L;
    private final List<Room> rooms=new ArrayList<>();
    public void addRoom(Room r){rooms.add(r);}
    public static void main(String[] args)throws Exception{
        Hostel h=new Hostel();Room room=new Room("A-101");
        room.add(new Resident("Anu","192311001","not-saved","9000000000"));h.addRoom(room);
        try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream("hostel.ser"))){out.writeObject(h);}
        System.out.println("Hostel object graph saved to hostel.ser");
    }
}
class Room implements Serializable {
    private static final long serialVersionUID=1L;
    private final String roomNo;private final List<Resident> residents=new ArrayList<>();
    Room(String roomNo){this.roomNo=roomNo;}void add(Resident r){residents.add(r);}
}
