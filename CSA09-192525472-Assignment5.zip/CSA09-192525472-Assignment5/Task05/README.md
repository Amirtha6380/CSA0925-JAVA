# A5 – Design for Correctness and Safety (4 marks)
## A5.1 Transaction pseudocode
1. SET auto-commit FALSE.
2. UPDATE source wallet: subtract ₹500 only when balance ≥ ₹500; require exactly one row.
3. UPDATE destination wallet: add ₹500; require exactly one row.
4. COMMIT only after both updates succeed.
5. ON any exception: ROLLBACK and report failure.
The transaction makes the two updates atomic: either both become permanent or neither does.
## A5.2 SQL injection
Concatenating untrusted `id` and `pwd` allows input to alter SQL syntax, potentially adding a tautology or commenting out the password predicate. Use `PreparedStatement` placeholders and bind both values; inputs remain data, not SQL code. Store salted password hashes in a real system rather than plaintext passwords.
## Alternative: independent auto-commit
If the debit commits and the application fails before credit, money is lost from the combined system. Two separate updates may have similar raw execution cost, but a transaction adds commit/rollback coordination and protects invariants. Correctness outweighs the small overhead.
## Run
The JDBC examples compile with a JDK; execution requires a configured database and schema. Credentials should be supplied via environment variables, never committed.
