# A3 – Discover the Data-Access Design Pattern (5 marks)
Repeated steps: acquire connection, prepare SQL, bind values, execute, map ResultSet, handle errors, close resources. Differences: entity/table/column names, keys, SQL and mapping rules.
`Dao<T,K>` standardizes insert, findById, findAll, update and delete. `StudentDao` implements it using parameterized SQL and try-with-resources. Student mapping: `id BIGINT PRIMARY KEY` ↔ `Student.id`; `reg_no VARCHAR(...)` ↔ `regNo`; `name VARCHAR(...)` ↔ `name`.
If SQL lives in GUI/service classes, a column rename requires edits in every caller. DAO centralizes SQL changes. Both designs have the same asymptotic database operation cost (dominated by query/index behavior); DAO adds negligible object/method overhead and improves maintainability.
## Run
Requires MySQL Connector/J and `sql/schema.sql`. Set `CSA09_DB_URL`, `CSA09_DB_USER`, `CSA09_DB_PASSWORD` before running a caller/test.
