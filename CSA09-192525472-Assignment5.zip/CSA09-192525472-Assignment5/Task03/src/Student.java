public class Student {
    private final long id; private final String regNo; private final String name;
    public Student(long id,String regNo,String name){this.id=id;this.regNo=regNo;this.name=name;}
    public long getId(){return id;} public String getRegNo(){return regNo;} public String getName(){return name;}
    public String toString(){return id+" | "+regNo+" | "+name;}
}
