import java.sql.*;
import java.util.*;
public class StudentDao implements Dao<Student,Long> {
    private final String url,user,password;
    public StudentDao(String url,String user,String password){this.url=url;this.user=user;this.password=password;}
    private Connection open() throws SQLException{return DriverManager.getConnection(url,user,password);}
    public Long insert(Student s)throws SQLException{
        String q="INSERT INTO student(reg_no,name) VALUES(?,?)";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,s.getRegNo());p.setString(2,s.getName());p.executeUpdate();
            try(ResultSet r=p.getGeneratedKeys()){if(r.next())return r.getLong(1);}
        } throw new SQLException("No generated key returned");
    }
    public Optional<Student> findById(Long id)throws SQLException{
        try(Connection c=open();PreparedStatement p=c.prepareStatement("SELECT id,reg_no,name FROM student WHERE id=?")){
            p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(new Student(r.getLong(1),r.getString(2),r.getString(3))):Optional.empty();}
        }
    }
    public List<Student> findAll()throws SQLException{
        List<Student> out=new ArrayList<>();
        try(Connection c=open();PreparedStatement p=c.prepareStatement("SELECT id,reg_no,name FROM student ORDER BY id");ResultSet r=p.executeQuery()){
            while(r.next())out.add(new Student(r.getLong(1),r.getString(2),r.getString(3)));
        }return out;
    }
    public boolean update(Student s)throws SQLException{
        try(Connection c=open();PreparedStatement p=c.prepareStatement("UPDATE student SET reg_no=?,name=? WHERE id=?")){
            p.setString(1,s.getRegNo());p.setString(2,s.getName());p.setLong(3,s.getId());return p.executeUpdate()==1;
        }
    }
    public boolean delete(Long id)throws SQLException{
        try(Connection c=open();PreparedStatement p=c.prepareStatement("DELETE FROM student WHERE id=?")){
            p.setLong(1,id);return p.executeUpdate()==1;
        }
    }
}
